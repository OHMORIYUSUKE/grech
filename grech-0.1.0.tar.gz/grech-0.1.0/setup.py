# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['Controller',
 'grech',
 'grech.Controller',
 'grech.Model.config',
 'grech.Model.result',
 'grech.Model.test',
 'grech.Model.testInfo',
 'grech.UseCase.config',
 'grech.UseCase.score',
 'grech.UseCase.test',
 'grech.UseCase.testinfo',
 'grech.Views']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'black>=22.6.0,<23.0.0',
 'fire>=0.4.0,<0.5.0',
 'pydantic>=1.9.1,<2.0.0',
 'rich>=12.5.1,<13.0.0']

entry_points = \
{'console_scripts': ['grech = grech.main:main']}

setup_kwargs = {
    'name': 'grech',
    'version': '0.1.0',
    'description': 'The yaml file can be freely written, and regular expressions can be tested using shell. In addition, when the test fails, an arbitrary message can be output.',
    'long_description': None,
    'author': 'Yusuke Ohmori',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
